Used grep to match patterns in question 1 and awk to calculate the sum
mkdir 2024201039
cd 2024201039
touch 2024201039_q1.sh
grep -E 'POST.*?404' access.log

touch 2024201039_q1.sh
awk -F',' '{s+=$4} END {print s}' power_levels.txt

Run this commands in the terminal